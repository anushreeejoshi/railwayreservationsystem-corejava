package com.project;

import java.sql.Connection;
import java.sql.DriverManager;

public class DataBaseConnection {

	static String driver ="com.mysql.cj.jdbc.Driver";
	static String url="jdbc:mysql://localhost:3306/projectdb";
	static String un="root";
	static String up="root";
	
	static Connection conn;
	public static Connection getConnection() {
		try {
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,up);
			if(conn==null) {
				System.out.println("Connection Error");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
}
