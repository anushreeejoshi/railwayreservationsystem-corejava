package com.project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CustomerClass {

	static Connection myconn = null;
	static ResultSet rs = null;
	static PreparedStatement pst = null;
	//newUserRegister() method variables
	static String username;
	static String password;
	static int userId;
	//bookSeat() tripdetails
	static String tripname;
	static String departure;
	static String arrival;
	static String name;
	//bookSeat() ticketdetails
	static float ticketprice;
	static String coach;
	static int tid;
	static float total;
	static int seatno;
	static long accno;
	static Scanner sc = new Scanner(System.in);

	/* new user registration
	 * it accepts user id, name, password then stores in database
	 * after successful registration it will ask for bank account details it is like digital wallet for 
	 * railway reservation system for booking ticket
	 */
	//new user registration
	public static void newUserRegister() throws SQLException {
		// TODO Auto-generated method stub
		System.out.println("Welcome To Railway Reservation System");
		
		myconn=DataBaseConnection.getConnection();
		String new_register="select * from new_user_register where userId=?";
		pst=myconn.prepareStatement(new_register);
		System.out.println("Enter User ID");
		userId=sc.nextInt();
		pst.setInt(1, userId);
		rs=pst.executeQuery();
		if(!rs.next()) {
			System.out.println("Enter user name to register");
			username=sc.next();
			System.out.println("Enter password");
			password=sc.next();
		while(true) {
				String userinsert="insert into new_user_register values(?,?,?)";
				pst=myconn.prepareStatement(userinsert);
				pst.setString(1,username);
				pst.setString(2, password);
				pst.setInt(3, userId);
				int i=pst.executeUpdate();
				if(i>0) {
					System.out.println("Successfully Registered!!!!");
					System.out.println("Create Bank Account In Railway System");
					System.out.println("Enter Your Account No");
					String cus_acc=sc.next();
					System.out.println("Enter Your Pin");
					int cus_acc_pin=sc.nextInt();
					System.out.println("Enter how much money you want to deposite");
					double bal=sc.nextDouble();
					String seldeposite="select * from customer_acc where userId=?";
					pst=myconn.prepareStatement(seldeposite);
					pst.setInt(1, userId);
					rs=pst.executeQuery();
					if(!rs.next()) {
						String deposite="insert into customer_acc values(?,?,?,?)";
						pst=myconn.prepareStatement(deposite);
						pst.setString(1, cus_acc);
						pst.setInt(2, cus_acc_pin);
						pst.setDouble(3, bal);
						pst.setInt(4, userId);
						int depo=pst.executeUpdate();
						if(depo>0) {
							System.out.println("Bank Account Created Successfully");
						}
					}
					break;
				}
			}
		}else {
			System.out.println("User ID is already Registered");
		}
		
	}
	//Registered User Login Process
	public static void userLogin() throws SQLException {
		// TODO Auto-generated method stub
		myconn=DataBaseConnection.getConnection();
		while(true) {
			System.out.println("Enter User Name");
			username=sc.next();
			System.out.println("Enter Password");
			password=sc.next();
			String checkusername="select * from new_user_register where user_name=?";
			pst=myconn.prepareStatement(checkusername);
			pst.setString(1, username);
			rs=pst.executeQuery();
			if(rs.next()) {
				String checkpassword="select * from new_user_register where password=?";
				pst=myconn.prepareStatement(checkpassword);
				pst.setString(1, password);
				rs=pst.executeQuery();
			if(rs.next()) {
				System.out.println("Login Successfull");
				
			while(true) {
				System.out.println("1. Seat Reservation");
				System.out.println("2. Seat Cancellation");
				System.out.println("3. Exit");
				
				System.out.println("Enter your choice..");
				int ch1=sc.nextInt();
				switch(ch1) {
				case 1: System.out.println("You choosed Seat Reservation");
				CustomerClass.bookTicket();
				break;
				case 2: System.out.println("You choosed Seat Cancellation");
				CustomerClass.cancelTicket();
				break;
				case 3://exit
				break;
				default: System.out.println("Invalid Choice");
				break;
				}
				
				System.out.println("Do you want to continue the seat reservation or seat cancellation yes/no");
				String in=sc.next();
				if(in.equalsIgnoreCase("no")) 
					break;
				
//				break;
			}
			
			}
			}else {
				System.out.println("Invalid user name");
				System.out.println("If you are already registred then again try to login");
				System.out.println("Otherwise go for Registration");
				System.out.println("Do you want to go for one more chance yes/no");
				String input=sc.next();
				if(input.equalsIgnoreCase("no")) {
					break;
				}
			} break;
		}
	}
	//Seat Reservation
	public static void bookTicket() throws SQLException {

		int totalNoOfSeats = 50;
		int avalseat=50;

		myconn = DataBaseConnection.getConnection();
		String seat = "select seatno from seatbook order by seatno";
		pst = myconn.prepareStatement(seat);
		rs = pst.executeQuery();
		while (rs.next()) {
			System.out.print(rs.getInt(1) + " ");
		}
		System.out.println("Already These seats are reserved");
		String count = "select count(*) from seatbook";
		pst = myconn.prepareStatement(count);
		rs = pst.executeQuery();
		while (rs.next()) {
			int reservedseat = rs.getInt(1);

			
			// selecting seat no
			while (true) {
//				System.out.println(reservedseat+" "+avalseat);
				System.out.println("Total number of seats " + totalNoOfSeats);
				System.out.println("available seat count " + (avalseat - reservedseat));
				System.out.println("Enter Seat No:");
				seatno = sc.nextInt();
				String sel = "select * from seatbook where seatno =?";
				pst = myconn.prepareStatement(sel);
				pst.setInt(1, seatno);
				rs = pst.executeQuery();
				// entering customer details
				if (!rs.next()) {
					System.out.println("Enter Customer Name:");
					 name = sc.next();
					System.out.println("Enter phone no:");
					String phone = sc.next();

					// select coach

			while(true) {
				System.out.println("Which Trip you want to choose");
				System.out.println("1. Banglore To Pune");
				System.out.println("2. Banglore To Mumbai");
				System.out.println("3. Banglore To Hyderabad");
				int ch=sc.nextInt();
				if(ch<4) {
					switch(ch) {
					case 1: System.out.println("You selected Banglore to Pune Trip");
					tripname="Banglore To Pune";
					break;
					case 2: System.out.println("You selected Banglore to Mumbai Trip");
					tripname="Banglore To Mumbai";
					break;
					case 3: System.out.println("You selected Banglore to Hyderabad Trip");
					tripname="Banglore to Hyderabad";
					break;
					}
					break;
				}else {
					System.out.println("Invalid Option");
				}
			}
			while(true) {
				System.out.println("Select which timing you want");
				System.out.println("1. DEPARTURE TIME is 6:00AM ARRIVAL TIME is 2:00PM");
				System.out.println("2. DEPARTURE TIME is 7:00AM ARRIVAL TIME is 5:00PM");
				System.out.println("3. DEPARTURE TIME is 3:00PM ARRIVAL TIME is 10:00PM");
				int ch=sc.nextInt();
				if(ch<4) {
					switch(ch){
					case 1: System.out.println("Your DEPARTURE TIME is 6:00AM");
					departure="6:00:00";
					System.out.println("Your ARRIVAL TIME is 2:00PM");
					arrival="2:00:00";
					
					break;
					case 2: System.out.println("Your DEPARTURE TIME is 7:00AM");
					departure="7:00:00";
					System.out.println("Your ARRIVAL TIME is 5:00PM");
					arrival="5:00:00";
					break;
					
					case 3: System.out.println("Your DEPARTURE TIME is 3:00PM");
					departure="3:00:00";
					System.out.println("Your ARRIVAL TIME is 10:00PM");
					arrival="10:00:00";
					break; 
					}
					break;
				}else {
					System.out.println("Invalid option..");
				}
			}
			 while (true) {
				System.out.println("Enter which ticket you want to book");
				System.out.println("1. First_AC  Price 1940 Rs");
				System.out.println("2. Second_AC  Price 1150 Rs");
				System.out.println("3. Third_AC  Price 950 Rs");
				tid = sc.nextInt();
				if (tid < 4) {
				switch (tid) {
				case 1:
					System.out.println("you selected first_AC ticket");
					coach = "First_AC";
					ticketprice = 1940;
					break;
				case 2:
				    System.out.println("you selected second_AC ticket");
					coach = "Second_AC";
					ticketprice = 1150;
					break;
				case 3:
					System.out.println("you selected third_AC ticket");
					coach = "Third_AC";
					ticketprice = 950;
					break;
					}
				break;
			    } else {
					System.out.println("invalid choice");
						}
					}
					// payment process
					while (true) {
						total = ticketprice;
						// System.out.println("total"+ticketprice+"\t"+total);
						System.out.println("Payment Section");
						System.out.println("Enter UserId:");
						userId=sc.nextInt();
						String checkUserid="select accno from customer_acc where userId=?";
						pst=myconn.prepareStatement(checkUserid);
						pst.setInt(1, userId);
						rs=pst.executeQuery();
						if(rs.next()) {
						System.out.println("Enter account no");
						accno = sc.nextLong();
						System.out.println("Enter pin");
						int pin = sc.nextInt();
						String paymentacc = "select accno from customer_acc where accno=?";
						pst = myconn.prepareStatement(paymentacc);
						pst.setLong(1, accno);
						rs = pst.executeQuery();
						if (rs.next()) {
							String paymentpin = "select pin from customer_acc where pin=?";
							pst = myconn.prepareStatement(paymentpin);
							pst.setInt(1, pin);
							rs = pst.executeQuery();
						
						if (rs.next()) {
							String in = "insert into seatbook values(?,?,?)";
							pst = myconn.prepareStatement(in);
							pst.setInt(1, seatno);
							pst.setString(2, name);
							pst.setString(3, phone);
							int j = pst.executeUpdate();
							
						if(j>0) {
							String ins1="insert into tripdetails values(?,?,?,?)";
							pst=myconn.prepareStatement(ins1);
							pst.setString(1,tripname);
							pst.setString(2, departure);
							pst.setString(3, arrival);
							pst.setInt(4, seatno);
							int k=pst.executeUpdate();
						

						if (k > 0) {
							String ins = "insert into ticketdetails values(?,?,?,?)";
							pst = myconn.prepareStatement(ins);
							pst.setString(1, coach);
							pst.setFloat(2, ticketprice);
							pst.setInt(3, seatno);
							pst.setFloat(4, total);
							int i = pst.executeUpdate();

						if (i > 0) {
							String bal = "select balance from customer_acc where(select balance from customer_acc where accno=?)>0";
							pst = myconn.prepareStatement(bal);
							pst.setLong(1, accno);
							rs = pst.executeQuery();
						if (rs.next()) {
							String withdraw = "update customer_acc set balance=balance-(select totalamt from ticketdetails where seatno=?)where accno=?";
							pst = myconn.prepareStatement(withdraw);
							pst.setInt(1, seatno);
							pst.setLong(2, accno);
//											;
						int t = pst.executeUpdate();

						if (t > 0) {
							    String deposite="insert into admin_account values(?,?)";
							    pst=myconn.prepareStatement(deposite);
							    pst.setFloat(1, total);
							    pst.setInt(2, seatno);
							    int l=pst.executeUpdate();
							    
							  if(l>0) {  
								System.out.println("Ticket Booked");
                                System.out.println("Do you want to see the whole details about your reservation yes/no");
                                String m=sc.next();
                                if(m.equalsIgnoreCase("yes")) {
                                	
                                    CustomerClass.displayReservation();
                                	totalNoOfSeats = totalNoOfSeats - 1;
    								
    								break;
                                }else {
    								break;
								
							} 
							}
						  break;
						}}
						else {
							System.out.println("insufficient balance");
							String del = "delete from seatbook where seatno =?";
							pst = myconn.prepareStatement(del);
							pst.setInt(1, seatno);
							int df = pst.executeUpdate();
							if (df > 0) {
							String del1 = "delete from ticketdetails where seatno =?";
							pst = myconn.prepareStatement(del1);
							pst.setInt(1, seatno);
							int ds = pst.executeUpdate();
						if (ds > 0) {
							System.out.println("check your balance");
							break;
							}
						}
						}
						}
					}
				}
				} 
				}else {
					System.out.println("invalid account no or pin");
					}
			break;	 
			}else{
			System.out.println("Invalid User Id");	
			
			}
						break;
			}
		}else {
			System.out.println("this seat no is already reserved");
		}
		avalseat = totalNoOfSeats - 1;
		
		break;
		
			}}

	}
	
	// display particular record
	public static void displayReservation() throws SQLException {
		myconn = DataBaseConnection.getConnection();
		String dis = "select * from seatbook where seatno=?";
		pst = myconn.prepareStatement(dis);
		pst.setInt(1, seatno);
		rs = pst.executeQuery();
		
		
		while (rs.next()) {
			System.out.println("************************Customer Details***********************");
			System.out.println("----------------------------------------------------------------");
			System.out.println("SeatNO\t\tCustomerName\t\tPhoneNo");
			int seatn = rs.getInt(1);
			String cname = rs.getString(2);
			String phoneno = rs.getString(3);
			System.out.println("----------------------------------------------------------------");
			System.out.println(seatn + "\t\t" + cname + "\t\t" + phoneno);
			System.out.println();
		}
		
		String sel1 = "select * from ticketdetails where seatno=?";
		pst = myconn.prepareStatement(sel1);
        pst.setInt(1, seatno);
		rs = pst.executeQuery();
		
		
		while (rs.next()) {
            System.out.println("**********************Ticket Details****************************");
            System.out.println("----------------------------------------------------------------");
            System.out.println("CoachName\t\tPrice\t\tSeatNo\t\tTotalAmt");
			String coach = rs.getString(1);
			float price = rs.getFloat(2);
			int seatn = rs.getInt(3);
			float total = rs.getFloat(4);
			System.out.println("----------------------------------------------------------------");
			System.out.println(coach + "\t\t" + price + "\t\t" + seatn + "\t\t" + total);
		}
	}

	
	
	//cancel ticket
	public static void cancelTicket() throws SQLException {
		myconn = DataBaseConnection.getConnection();
		while (true) {
			System.out.println("Enter Your User name");
			username=sc.next();
			System.out.println("Enter Your Password");
			password=sc.next();
			System.out.println("Enter User ID");
			userId=sc.nextInt();
			System.out.println("Enter Your Seat No");
			seatno=sc.nextInt();
			String sel = "select * from new_user_register where userId=?";
			pst = myconn.prepareStatement(sel);
			pst.setInt(1, userId);
			rs = pst.executeQuery();
			if(rs.next()) {
			String sel1="select * from new_user_register where user_name=?";
			pst = myconn.prepareStatement(sel1);
			pst.setString(1, username);
			rs = pst.executeQuery();
			
			if(rs.next()) {
			String refund="select * from ticketdetails where seatno=?";
			pst=myconn.prepareStatement(refund);
			pst.setInt(1, seatno);
			rs = pst.executeQuery();
			while(rs.next()) {
			float moneyreturn=rs.getFloat(4);
			
			String sel2="select * from new_user_register where password=?";
			pst = myconn.prepareStatement(sel2);
			pst.setString(1, password);
			rs = pst.executeQuery();
			if(rs.next()) {
			String sel3="select seatno=? from seatbook where  cname=?";
			pst=myconn.prepareStatement(sel3);
			pst.setInt(1, seatno);
			pst.setString(2, username);
			rs=pst.executeQuery();
			if (rs.next()) {
				String del = "delete from seatbook where seatno=?";
				pst = myconn.prepareStatement(del);
				pst.setInt(1, seatno);
				int d = pst.executeUpdate();

				if (d > 0) {
					String del1 = "delete from ticketdetails where seatno=?";
					pst = myconn.prepareStatement(del1);
					pst.setInt(1, seatno);
					int d1 = pst.executeUpdate();
					
				if(d1>0) {
					String del2="delete from admin_account where seatno=?";
					pst = myconn.prepareStatement(del2);
					pst.setInt(1, seatno);
					int d2 = pst.executeUpdate();
				if(d2>0) {
					String del3="delete from tripdetails where seatno=?";
					pst=myconn.prepareStatement(del3);
				    pst.setInt(1, seatno);
                    int d3=pst.executeUpdate();
                   
					if (d3 > 0) {
						System.out.println("Your Reservation is cancelled");
//						System.out.println(moneyreturn+" "+userId);
						String refund2="update customer_acc set balance=balance+? where userId=?";
						pst=myconn.prepareStatement(refund2);
						pst.setFloat(1, moneyreturn);
						pst.setInt(2, userId);
						int rfd=pst.executeUpdate();
						if(rfd>0) {
							System.out.println("Money refunded successfully into your account");
						}
						break;
					}
				}
				}
				}
			}} else {
				System.out.println("you not reserved any seat");

			}
			}}
            break;
	}else {
		System.out.println("Invalid UserID");
	}
	

	
	}}}
