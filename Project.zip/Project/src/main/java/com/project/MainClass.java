/*                        Railway Reservation System
 *                      CSR CAPGEMINI TRAINING PROJECT
 *                      EDUBRIDGE INDIA PRIVATE LIMITED
 *               PROJECT TITLE: RAILWAY RESERVATION SYSTEM 
 *              UNDER THE GUIDENCE OF TRAINER MRS.INDRAKA MALLI                                                         
 *                                             @DONE BY Anushree Joshi
 * In RAILWAY RESERVATION SYSTEM:
 * MAIN OPERATIONS:
 * 1.REGISTRATION         -->passenger can perform that operation.
 * 2.LOGIN                -->Both admin and passenger can perform that operation.
 * 3.SEAT RESERVATION     -->Passenger can perform that operation.
 * 4.SEAT CANCELLATION    -->passenger can perform that operation.
 * 5.DISPLAY              -->Both the admin and passenger perform the operation.
 * 
 * case 1: Admin login 
 * Admin screen
 * 1. show user ticket details
 * 2. show how many tickets are reserved
 * case 2: New Customer login
 * - It will register the new user 
 * case 3: Registered Customer
 * - registered user can book ticket 
                                          

 */
package com.project;

import java.sql.SQLException;
import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) throws SQLException{
		// TODO Auto-generated method stub
		String un="admin";
		String userpass="admin123";
		while(true) {
			System.out.println("*******************Railway Reservation System******************");
		int ch;
		Scanner sc=new Scanner(System.in);
		System.out.println("Login/Admin or User");
		
		System.out.println("1. Admin login");
		System.out.println("2. New Customer Login");
		System.out.println("3. Registered Customer");
		System.out.println("4. Exit");
		System.out.println("Enter your choice");
		ch=sc.nextInt();
		
		switch(ch) {
		
		case 1: 
			System.out.println("For admin login please enter credentials");
			System.out.println("Enter name");
			String aname=sc.next();
			System.out.println("Enter password");
			String password=sc.next();
			if(aname.equals("admin")&& password.equals("admin123")) {
			    System.out.println("------------------Admin Screen------------------");
		        System.out.println("Admin Options");
		        System.out.println("1. Show User Ticket Details");
		        System.out.println("2. Show Reserved Seats");
		        
		        System.out.println("Enter your choice");
		        int adminch=sc.nextInt();
		        switch(adminch) {
		        case 1: System.out.println("Display  all tickets details"); 
		                AdminClass.displayCustomer();
		        	break;
		        case 2: System.out.println("Display How many seats are reserved");
		                AdminClass.admin_account();
		        break;
		        	
		        default: System.out.println("Invalid choice");
		        }
		        break;
			}
			break;
		case 2:	System.out.println("------------------New User Registration------------------");
		        CustomerClass.newUserRegister();
		        break;
		case 3: //User login
			System.out.println("------------------Registered User Login------------------");
			CustomerClass.userLogin();
			break;
		case 4: //exit
			break;
		}
			System.out.println("Type y if you want to continue or press n to terminate");
			ch=sc.next().charAt(0);
			if(ch=='n'||ch=='N') 
				break;
		
		}
		System.out.println("Program is terminated");

	}

}
