package com.project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.project.DataBaseConnection;

/*
* In this admin login process the back end we created one user name and password for the admin
*
* That user name and password can be used to login admin login module
*
* If the login process get successful means admin can perform display operations
*
* 1.display details of all seats  -> it gives information all the seat number
*
* 2.display seatreserved-> it gives result about how many seats are reserved
*
*/

public class AdminClass {

	static Connection myconn=null;
	static ResultSet rs=null;
	static PreparedStatement pst=null;
	
	static Scanner sc=new Scanner(System.in);
	
	//display all customer details
	public static void displayCustomer() throws SQLException {
		myconn=DataBaseConnection.getConnection();
		String sel="select * from seatbook";
		pst=myconn.prepareStatement(sel);
		
		rs=pst.executeQuery();
		
		System.out.println("Display User Details");
		System.out.println("SeatNo\t\tCustomerName\tPhoneNo");
		while(rs.next()) {
			
			int seatn=rs.getInt(1);
			String cname=rs.getString(2);
			String phoneno=rs.getString(3);
			
			System.out.println(seatn+"\t\t"+cname+"\t\t"+phoneno);
		}
		String sel1="select * from ticketdetails ";
		pst=myconn.prepareStatement(sel1);
		rs=pst.executeQuery();
		System.out.println("Display Reserved Ticket Details");
		System.out.println("CoachName\t\tPrice\t\tSeatNo\t\tTotalAmt");
		while(rs.next()) {
			
			String coach=rs.getString(1);
			float price=rs.getFloat(2);
			int seatn=rs.getInt(3);
			float total=rs.getFloat(4);
			System.out.println(coach+"\t\t"+price+"\t\t"+seatn+"\t\t"+total);
		}
	}
	
	//admin account details
	public static void admin_account() throws SQLException {
		myconn=DataBaseConnection.getConnection();
		String count_seat="select count(*) from admin_account";
		pst=myconn.prepareStatement(count_seat);
		rs=pst.executeQuery();
		while(rs.next()) {
		System.out.println("Total Seats Reserved="+rs.getInt(1));
		}
		String acc="select * from admin_account";
		pst=myconn.prepareStatement(acc);
		rs=pst.executeQuery();
		System.out.println("Display Reserved Seats");
		System.out.println("TotalAmount\tSeatNo");
		while(rs.next()) {
			float total=rs.getFloat(1);
			int seatno=rs.getInt(2);
			
			System.out.println(total+"\t\t"+seatno);
		}
	}
	
		
	
	
}
